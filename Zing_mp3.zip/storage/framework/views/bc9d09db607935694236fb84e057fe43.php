
<?php $__env->startSection('title', '<?php echo e($artist->name); ?>'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/artist/main.css')); ?>">


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="search-content">
    
        <div class="content-banner">
            <div class="bg-banner">
                <div class="blur" style="background-image: url( '<?php echo e($artist->avatar); ?>' );"></div>
                <div class="bg-banner-color">

                </div>
            </div>
            <div class="content-banner-info">
                <div class="info-wrapper">
                    <div class="info-avatar">
                        <img src="<?php echo e($artist->avatar); ?>" alt="">
                    </div>
                    <div class="info-content">
                        <div class="info-content-title">
                            <h3><?php echo e($artist->name); ?></h3>
                            <div class="wrapper-icon" onclick="playListSongArtist('<?php echo e($artist->id); ?>')">
                            <i class="fa-solid fa-play"></i>
                            </div>
                        </div>
                        <?php

                        
                        ?>
                        <div class="info-content-des">
                            <span><?php echo e($artist->total_followers); ?> người quan tâm</span>
                            <div class="artist-action">
                            
                            <button class="artist-action-follow <?php if(auth()->guard('user')->check()): ?> <?php if(auth('user')->user()->checkFollowArtists($artist->id)): ?> active <?php endif; ?> <?php endif; ?>" data-name-artist="<?php echo e($artist->name); ?>" <?php if(auth()->guard('user')->check()): ?> onclick="setFolowerArtist(this,'<?php echo e($artist->id); ?>')" <?php else: ?> onclick="showAlerLogin()" <?php endif; ?>>
                                <div class="wrapper-icon">
                                    <i class="fa-solid fa-user-plus"></i>
                                </div>
                                <div class="artist-action-title">
                                <?php if(auth()->guard('user')->check()): ?> <?php if(auth('user')->user()->checkFollowArtists($artist->id)): ?> Bỏ theo dõi <?php else: ?> Theo dõi <?php endif; ?> <?php endif; ?>
                                </div>
                            </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="search-content">
            <div class="search-content-items">
                <?php if($artist->songs->count() > 0): ?>
                <div class="search-content-item-title">
                    <p>Bài hát</p>
                    <a href="<?php echo e(route('site.artist.song',['aritistSlug'=>$artist->slug])); ?>">Tất cả</a>
                </div>
                <div class="search-list-song">
                    <?php $__currentLoopData = $artist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-content-item-song">
                                <?php if (isset($component)) { $__componentOriginal40d7a89479f4bcd0af537566bf834f7f = $component; } ?>
<?php $component = App\View\Components\Song::resolve(['song' => $song] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('song'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Song::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f)): ?>
<?php $component = $__componentOriginal40d7a89479f4bcd0af537566bf834f7f; ?>
<?php unset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f); ?>
<?php endif; ?>
                            </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="search-content-items">
                <div class="search-content-item-title">
                    <p>Album</p>
                    <a href="<?php echo e(route('site.artist.album',['aritistSlug'=>$artist->slug])); ?>">Tất cả</a>
                </div>
                <div class="search-list-album">     
                    <?php if (isset($component)) { $__componentOriginal8b153d992a618214d8560d74c163a055 = $component; } ?>
<?php $component = App\View\Components\ListAlbum::resolve(['title' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-album'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListAlbum::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b153d992a618214d8560d74c163a055)): ?>
<?php $component = $__componentOriginal8b153d992a618214d8560d74c163a055; ?>
<?php unset($__componentOriginal8b153d992a618214d8560d74c163a055); ?>
<?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/artist/home.blade.php ENDPATH**/ ?>