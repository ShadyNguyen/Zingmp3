

<?php $__env->startSection('title', 'Trang chủ'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/home.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listSong.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/slide.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="home-page-content">
    <?php if (isset($component)) { $__componentOriginale8463facbfab87ccd5cf1962a07be4de = $component; } ?>
<?php $component = App\View\Components\Slide::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Slide::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8463facbfab87ccd5cf1962a07be4de)): ?>
<?php $component = $__componentOriginale8463facbfab87ccd5cf1962a07be4de; ?>
<?php unset($__componentOriginale8463facbfab87ccd5cf1962a07be4de); ?>
<?php endif; ?>
    <div class="home-page-content-items">
        <div class="list-song-wrapper">
            <div class="main-items-header">
                <div class="items-header-subtitle">
                    <span>Bắt đầu nghe từ một bài hát</span>
                </div>
                <div class="items-header-title">
                    Gợi Ý Từ top 10 bài hát có lượt nge cao nhất
                </div>
            </div>
            <div class="main-items-content">
                <?php $__currentLoopData = $topSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- item -->
                <?php if (isset($component)) { $__componentOriginal40d7a89479f4bcd0af537566bf834f7f = $component; } ?>
<?php $component = App\View\Components\Song::resolve(['song' => $song] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('song'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Song::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f)): ?>
<?php $component = $__componentOriginal40d7a89479f4bcd0af537566bf834f7f; ?>
<?php unset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f); ?>
<?php endif; ?>
                <!-- End item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="home-page-content-items">
        <?php if (isset($component)) { $__componentOriginal8b153d992a618214d8560d74c163a055 = $component; } ?>
<?php $component = App\View\Components\ListAlbum::resolve(['title' => 'Có Thể Bạn Muốn Nghe'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-album'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListAlbum::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b153d992a618214d8560d74c163a055)): ?>
<?php $component = $__componentOriginal8b153d992a618214d8560d74c163a055; ?>
<?php unset($__componentOriginal8b153d992a618214d8560d74c163a055); ?>
<?php endif; ?>



    </div>

    <?php if($topArtists->count() > 0): ?>
    <div class="home-page-content-items">
            <?php if (isset($component)) { $__componentOriginal156d4e47651829e0e0907f9a89bf46fc = $component; } ?>
<?php $component = App\View\Components\ListArtist::resolve(['listArtists' => $topArtists,'title' => 'Top 10 nghệ sĩ'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-artist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListArtist::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal156d4e47651829e0e0907f9a89bf46fc)): ?>
<?php $component = $__componentOriginal156d4e47651829e0e0907f9a89bf46fc; ?>
<?php unset($__componentOriginal156d4e47651829e0e0907f9a89bf46fc); ?>
<?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/home.blade.php ENDPATH**/ ?>