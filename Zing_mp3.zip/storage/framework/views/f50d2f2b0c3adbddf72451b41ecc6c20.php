
<?php $__env->startSection('title', 'Tìm kiếm'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/partials/paginateCustom.css')); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="search-content">
        <div class="search-header">
            <div class="search-header-content">
                <div class="header-content-title">
                    <h3>Kết quả tìm kiếm</h3>
                </div>
                <div class="border-height" style="height: 4rem;">
                    <div></div>
                </div>
                <a href="<?php echo e(route('site.search.all', ['q' => 'a'])); ?>" class="header-content-item">
                    <span>
                        Tất cả
                    </span>
                </a>
                <a href="<?php echo e(route('site.search.song', ['q' => 'a'])); ?>" class="header-content-item">
                    <span>
                        Bài hát
                    </span>
                </a>
                <a href="<?php echo e(route('site.search.playlist', ['q' => 'a'])); ?>" class="header-content-item active">
                    <span>
                        Playlist
                    </span>
                </a>
                <a href="<?php echo e(route('site.search.artist', ['q' => 'a'])); ?>" class="header-content-item">
                    <span>
                        Nghệ sĩ
                    </span>
                </a>
            </div>
        </div>
        <div class="search-content">
            

            <div class="search-content-items">
                <div class="search-content-item-title">
                    <p>Album</p>
                    <div>
                    <?php echo e($listAlbum->withQueryString()->links('partials.paginateCustom')); ?>


                    </div>
                </div>
                <div class="search-list-album">     
                    <?php if (isset($component)) { $__componentOriginal8b153d992a618214d8560d74c163a055 = $component; } ?>
<?php $component = App\View\Components\ListAlbum::resolve(['title' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-album'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListAlbum::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b153d992a618214d8560d74c163a055)): ?>
<?php $component = $__componentOriginal8b153d992a618214d8560d74c163a055; ?>
<?php unset($__componentOriginal8b153d992a618214d8560d74c163a055); ?>
<?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/search/album.blade.php ENDPATH**/ ?>