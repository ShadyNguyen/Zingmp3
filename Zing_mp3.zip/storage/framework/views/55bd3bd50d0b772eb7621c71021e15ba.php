<div class="list-artist-wrapper">
    <?php if(!empty($title)): ?>
    <div class="main-items-header">
        <div class="items-header-title">
            <?php echo e($title); ?>

        </div>
    </div>
    <?php endif; ?>
    <div class="main-items-content artist">
        <?php $__currentLoopData = $listArtists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php

        $stringJS = '';
        $isFollowed = false;
        if ($user) {
            if ($user->checkFollowArtists($artist->id)) {
                $isFollowed = true;
            }
            $stringJS =  "onclick=setFolowerArtist(this,'".$artist->id."')";
        }
        ?>
        <div class="artist-item">
            <div class="wrapper-avatar">
                
                <div class="wrapper-avatar-content" onclick="playListSongArtist('<?php echo e($artist->id); ?>')">

                    <div class="artist-avatar">
                        <img src="<?php echo e($artist->avatar); ?>" alt="">
                    </div>
                    <div class="wrapper-icon">
                        <i class="fa-solid fa-shuffle"></i>
                    </div>
                </div>

            </div>

            <div class="artist-info">
                <div class="artist-info-name">
                    <a href="<?php echo e(route('site.artist.home',['aritistSlug' => $artist->slug])); ?>"><?php echo e($artist->name); ?></a>
                </div>
                <div class="artist-info-follower">
                    <a><?php echo e($artist->total_followers); ?>K quan tâm</a>
                </div>
            </div>
            <div class="artist-action">
                <?php if($isFollowed): ?>
                <button class="artist-action-follow active" data-name-artist="<?php echo e($artist-> name); ?>" <?php echo e($stringJS); ?>>
                    <div class="wrapper-icon">
                        <i class="fa-solid fa-shuffle"></i>
                    </div>
                    <div class="artist-action-title">
                        Bỏ theo dõi
                    </div>
                </button>

                <?php else: ?>
                
                <button class="artist-action-follow" data-name-artist="<?php echo e($artist-> name); ?>" <?php if(auth()->guard('user')->check()): ?> <?php echo e($stringJS); ?> <?php else: ?> onclick="showAlerLogin()" <?php endif; ?>>
                    <div class="wrapper-icon">
                        <i class="fa-solid fa-user-plus"></i>
                    </div>
                    <div class="artist-action-title">
                        Theo dõi
                    </div>
                </button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/components/list-artist.blade.php ENDPATH**/ ?>