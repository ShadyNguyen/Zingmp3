
<?php $__env->startSection('title', 'Tìm kiếm'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/partials/paginateCustom.css')); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="search-content">
        <div class="search-header">
            <div class="search-header-content">
                <div class="header-content-title">
                    <h3>Yêu thích</h3>
                </div>
                <div class="border-height" style="height: 4rem;">
                    <div></div>
                </div>
                <a href="<?php echo e(route('site.mymusic.favorite',['type'=>'song'])); ?>" class="header-content-item">
                    <span>
                        Bài hát
                    </span>
                </a>
                <a href="<?php echo e(route('site.mymusic.favorite',['type'=>'playlist'])); ?>" class="header-content-item active">
                    <span>
                        Playlist
                    </span>
                </a>
                
            </div>
        </div>
        <div class="search-content">
            <?php if($listPlaylistFavorite->count() == 0): ?>
            <div class="search-content-items no-content">
                    <div class="wrapper-icon">
                        <i class="fa-solid fa-compact-disc"></i>
                    </div>
                    <p>Bạn chưa yêu thích bài hát nào</p>
            </div>  
            <?php else: ?>
            <div class="search-content-items">
                <div class="search-content-item-title">
                    <p>Album</p>
                    <div>
                    <?php echo e($listPlaylistFavorite->withQueryString()->links('partials.paginateCustom')); ?>


                    </div>
                </div>
                <div class="search-list-album">     
                    <?php if (isset($component)) { $__componentOriginal8b153d992a618214d8560d74c163a055 = $component; } ?>
<?php $component = App\View\Components\ListAlbum::resolve(['title' => '','listAlbum' => $listPlaylistFavorite] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-album'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListAlbum::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b153d992a618214d8560d74c163a055)): ?>
<?php $component = $__componentOriginal8b153d992a618214d8560d74c163a055; ?>
<?php unset($__componentOriginal8b153d992a618214d8560d74c163a055); ?>
<?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/mymusic/favorite/favoritePlaylist.blade.php ENDPATH**/ ?>