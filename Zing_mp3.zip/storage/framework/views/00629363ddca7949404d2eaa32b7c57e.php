
<?php $__env->startSection('title', 'Chỉnh sửa'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/partials/paginateCustom.css')); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="search-content">

    <div class="search-header">
        <div class="search-header-content">
            <div class="header-content-title">
                <h3>Bài hát</h3>
            </div>
            <div class="border-height" style="height: 4rem;">
                <div></div>
            </div>

            <a href="#" class="header-content-item active">
                <span>
                    <?php echo e($song->name); ?>

                </span>
            </a>

        </div>
    </div>
    <div class="search-content">
        <div class="search-content-items search-content-header">
            <div class="items-content edit">
                <div class="wrapper-items-album">
                    <div class="items-album-img">
                        <img src="<?php echo e($song->getThumnail(480) ? $song->getThumnail(480) : 'anh.jp'); ?>" alt="" onerror="replaceEmptyImage(this)">
                    </div>
                    <button class="item-actions play" onclick="addSongToListBtn('<?php echo e($song->id); ?>')">
                        <i class="fa-regular fa-circle-play"></i>
                    </button>
                </div>
                <div class="name-user-album">
                    <div class="action">
                        <a href="#" class="name"><?php echo e($song->name); ?>

                            <span>
                                <?php if(auth()->guard('user')->check()): ?>
                                <?php if(Auth::guard('user')->user()->checkLikeSong($song->id)): ?>
                                <button class="item-actions" data-name-song="<?php echo e($song->name); ?>" onclick="likeSong(this,'<?php echo e($song->id); ?>')">
                                    <i class="fa-solid fa-heart active"></i>
                                </button>

                                <?php else: ?>
                                <button class="item-actions" data-name-song="<?php echo e($song->name); ?>" onclick="likeSong(this,'<?php echo e($song->id); ?>')">
                                    <i class="fa-regular fa-heart"></i>
                                </button>
                                <?php endif; ?>
                                <?php else: ?>
                                <button class="item-actions" onclick="showAlerLogin()">
                                    <i class="fa-regular fa-heart"></i>
                                </button>
                                <?php endif; ?>
                            </span>
                        </a>
                    </div>

                    <span>Tác giả <strong><a href="<?php echo e(route('site.artist.home',['aritistSlug'=>$song->user->slug])); ?>"><?php echo e($song->user->name); ?></a></strong> </span>
                    <span> Ngày phát hành <strong><?php echo e($handleDate($song->created_at)); ?> </strong></span>
                    <span> <?php echo e($song->total_like); ?> lượt thích • <?php echo e($song->total_listen); ?> lượt nge</span>

                    <button class="btn-outline" onclick="playListSongArtist('<?php echo e($song->user->id); ?>')">
                        <i class="fa-solid fa-play"></i>
                        <span>PHÁT TẤT CẢ</span>
                    </button>
                </div>
            </div>
            <div style="width: 100%;">
                <div class="edit-wrapper">
                    <div class="search-content-item-title">
                        <p>Bài hát cùng tác giả</p>
                    </div>
                    <?php
                        $filtered_songs = $song->user->songs->filter(function ($songItem) use ($song) {
                        return $songItem->id !== $song->id;
                        });
                    ?>
                    <?php $__currentLoopData = $filtered_songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $songItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="search-content-item-song">
                        <?php if (isset($component)) { $__componentOriginal40d7a89479f4bcd0af537566bf834f7f = $component; } ?>
<?php $component = App\View\Components\Song::resolve(['song' => $songItem,'isDelete' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('song'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Song::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f)): ?>
<?php $component = $__componentOriginal40d7a89479f4bcd0af537566bf834f7f; ?>
<?php unset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f); ?>
<?php endif; ?>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if($filtered_songs->count() == 0): ?>
                <div class="search-content-items no-content">
                    <div class="wrapper-icon">
                        <i class="fa-solid fa-compact-disc"></i>
                    </div>
                    <p>Không còn bài hát nào</p>
                </div>
                <?php endif; ?>
            </div>


        </div>

    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/song.blade.php ENDPATH**/ ?>