

<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Đăng nhập</title>
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/style_login.css')); ?>">
    <link rel="icon" href="<?php echo e(url('public/site/img/logo-icon.png')); ?>">

    <style>
      .error{
        color:red;

        margin-top: 15px;
        display:block;
        font-weight:bold;
        font-style: italic;
        text-align: center;
      }
      .none{
        display: none;
      }
    </style>
  </head>
  <body>
    <div class="center">
      <h1>Đăng nhập Admin</h1>
      <form  action="<?php echo e(route('admin.auth.login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php if(session('error')): ?>
          <p class="error"><?php echo e(session('error')); ?></p>
        <?php endif; ?>
        <div class="txt_field">
          <input type="text" required name='username'>
          <span></span>
          <label>Tài khoản</label>
        </div>
        <div class="txt_field">
          <input type="password" required name='password'>
          <span></span>
          <label>Mật khẩu</label>
        </div>
       
        <input type="submit" value="Login">
        <div class="signup_link">
          
        </div>
      </form>
    </div>

  </body>
</html>
<?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/admin/login.blade.php ENDPATH**/ ?>