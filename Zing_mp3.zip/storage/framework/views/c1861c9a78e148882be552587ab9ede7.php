
<?php $__env->startSection('title', 'Chỉnh sửa'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/partials/paginateCustom.css')); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="search-content">

    <div class="search-header">
        <div class="search-header-content">
            <div class="header-content-title">
                <h3>Playlist của tôi</h3>
            </div>
            <div class="border-height" style="height: 4rem;">
                <div></div>
            </div>

            <a href="<?php echo e(route('site.mymusic.playlist')); ?>" class="header-content-item active">
                <span>
                    Playlist
                </span>
            </a>

        </div>
    </div>
    <div class="search-content">
        <div class="search-content-items search-content-header">
            <div class="items-content edit">
                <div class="wrapper-items-album">
                    <div class="items-album-img">
                        <img src="<?php echo e($playlist->avatar ? $playlist->avatar : 'anh.jp'); ?>" alt="" onerror="replaceEmptyImage(this)">
                    </div>
                    <button class="item-actions play" <?php if($playlist->songs->count() > 0): ?>
                        onclick="playAlbum('<?php echo e($playlist->id); ?>')"
                        <?php else: ?>
                        onclick="addNotification('notification','Danh sách phát này chưa có bài hát',3000)"
                        <?php endif; ?>
                        >
                        <i class="fa-regular fa-circle-play"></i>
                    </button>
                </div>
                <div class="name-user-album">
                    <div class="action">
                        <a href="#" class="name"><?php echo e($playlist->title); ?></a>
                        <div class="wrapper-icon" onclick="showModalEditPlaylist()" data-bs-toggle="tooltip" data-bs-placement="top" title="Chỉnh sửa">
                            <i class="fa-solid fa-pen"></i>
                        </div>
                    </div>

                    <span>Tạo bởi <strong><?php echo e($playlist->user->name); ?></strong> </span>
                    <span> <?php echo e($playlist->status? "Công khai": "Riêng tư"); ?> </span>

                </div>
            </div>
            <div style="width: 100%;">
            <div class="edit-wrapper">
                <div class="search-content-item-title">
                    <p>Bài hát</p>
                </div>
                    <?php $__currentLoopData = $playlist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="search-content-item-song">
                        <?php if (isset($component)) { $__componentOriginal40d7a89479f4bcd0af537566bf834f7f = $component; } ?>
<?php $component = App\View\Components\Song::resolve(['song' => $song,'isDelete' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('song'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Song::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f)): ?>
<?php $component = $__componentOriginal40d7a89479f4bcd0af537566bf834f7f; ?>
<?php unset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f); ?>
<?php endif; ?>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($playlist->songs()->count() == 0): ?>
            <div class="search-content-items no-content">
                <div class="wrapper-icon">
                    <i class="fa-solid fa-compact-disc"></i>
                </div>
                <p>Không có bài hát nào</p>
            </div>
            <?php endif; ?>
            </div>
            

        </div>
        
    </div>
    <input value="<?php echo e($playlist->id); ?>" id="_idPlaylist" type="hidden">
    <!-- Modal add playlist -->
    <div class="modal fade modal-add-playlist" id="modal-edit-play-list" tabindex="-1" aria-labelledby="modal-edit-play-list" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class=" modal-wrapper">
                    <div class="header-model d-flex">
                        <h3>
                            Chỉnh sửa playlist
                        </h3>
                        <div class="wrapper-icon" data-bs-dismiss="modal" aria-label="Close">
                            <i class="fa-solid fa-xmark"></i>
                        </div>
                    </div>
                    <div class="action-item-content">
                        <input type="text" value="<?php echo e($playlist->title); ?>" placeholder="Nhập tên playlist" id="name-edit-playlist" autocomplete="off">
                    </div>
                    <div class="action-model">
                        <div class="action-model-content">
                            <p>Công khai</p>
                            <span>Mọi người có thể nhìn thấy playlist này</span>
                        </div>
                        <div class="action-model-action">
                            <div class="form-check form-switch swich-model">
                                
                                <input <?php if($playlist->status): ?> checked <?php endif; ?> class="form-check-input" id="status-edit-playlist" type="checkbox" name="check-status-edit-playlist">
                            </div>
                        </div>
                    </div>
                    <div class="action-model">
                        <div class="action-model-content">
                            <p>Phát ngẫu nhiên</p>
                            <span>Luôn phát ngẫu nhiên các bài hát</span>
                        </div>
                        <div class="action-model-action">
                            <div class="form-check form-switch swich-model">
                                <input class="form-check-input" type="checkbox">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn-modal" id="btn-edit-play-list" onclick="submitEditPlayList('<?php echo e($playlist->id); ?>')">
                    <button>Sửa</button>
                </div>
                <?php if(auth()->guard('user')->check()): ?>
                <input type="hidden" value="<?php echo e(Auth::guard('user')->user()->id); ?>">
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- End Modal add playlist -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script>
        const modalEditPlaylist = new bootstrap.Modal(document.getElementById('modal-edit-play-list'), options)
        const _id_playlist = document.getElementById('_idPlaylist').value;
        
        function showModalEditPlaylist() {
            modalEditPlaylist.show();
        }

        function submitEditPlayList(id_playlist) {
            const newName = document.getElementById('name-edit-playlist').value
            const newStatus = document.getElementById('status-edit-playlist').checked
            if (newName) {
                editPlayListCall(id_playlist, newName, newStatus);
            } else {
                addNotification(
                    ID_NOTIFICATION,
                    "Nhập đầy đủ thông tin",
                    4000
                );
            }
        }

        function editPlayListCall(id_playlist, newName, newStatus) {
            const urlCall = URL_WEB + "/api/editPlaylist"; // Thay đổi địa chỉ URL thành endpoint của bạn

            const id_user = _idUser.value;
            const formData = new FormData();


            formData.append("id_user", id_user);
            formData.append("id_playlist", id_playlist);
            formData.append("newName", newName);
            formData.append("newStatus", newStatus);


            // Gửi yêu cầu POST bằng Axios
            axios
                .post(urlCall, formData, {
                    headers: {
                        "Content-Type": "application/json", // Định dạng dữ liệu gửi lên là JSON
                        Accept: "application/json", // Header Accept: application/json
                    },
                })
                .then((response) => {
                    // Xử lý phản hồi từ máy chủ ở đây

                    const status = response.status;
                    if (status === 204) {
                        // Load lại trang web hiện tại
                        return id_playlist

                        // parentN.remove();
                    }
                })
                .then((id_playlist) => {
                    addNotification(
                        ID_NOTIFICATION,
                        setStringAction("Chỉnh sửa playlist", " ", "thành công!"),
                        4000
                    );
                    setTimeout(() => {
                        location.reload();
                    }, 1500)
                })
                .catch((error) => {

                    const status = error.response.status;

                    if (status === 422) {
                        addNotification(ID_NOTIFICATION, "Có lỗi, thử lại sau!", 4000);
                    } else {
                        addNotification(ID_NOTIFICATION, "Có lối, thử lại sau!", 4000);
                    }
                });
        }
    </script>

    
    <script>
        function removeSongFromPlaylist(id_song,name_song){
            const urlCall = URL_WEB + "/api/deleteSongFromPlayList"; // Thay đổi địa chỉ URL thành endpoint của bạn

            const id_user = _idUser.value;
            const id_playlist = _id_playlist
            params = {
                id_user,
                id_playlist,
                id_song
            };

            // Gửi yêu cầu POST bằng Axios
            axios
                .get(urlCall, { params })
                .then((response) => {
                    // Xử lý phản hồi từ máy chủ ở đây

                    const status = response.status;
                    if (status === 204) {
                        // Load lại trang web hiện tại
                        return id_playlist

                        // parentN.remove();
                    }
                })
                .then((id_playlist) => {
                    addNotification(
                        ID_NOTIFICATION,
                        setStringAction("xóa thành công bài hát", name_song, "ra khỏi playlist!"),
                        4000
                    );
                    const pr = document.querySelector('div.wrapper-items-song.dropdown[data-song-id="' + id_song + '"]');
                    pr.remove();
                })
                .catch((error) => {

                    // const status = error.response.status;

                    if (status === 422) {
                        addNotification(ID_NOTIFICATION, "Có lỗi, thử lại sau!", 4000);
                    } else {
                        addNotification(ID_NOTIFICATION, "Có lối, thử lại sau!", 4000);
                    }
                });
        }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/mymusic/playlist/edit.blade.php ENDPATH**/ ?>