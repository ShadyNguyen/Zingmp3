
<div class="list-album-wrapper">
    <?php if(!empty($title)): ?>
    <div class="main-items-header">
        <div class="items-header-title">
            <?php echo e($title); ?>

        </div>
    </div>
    <?php endif; ?>
    <div class="main-items-content album">
        <?php if($addAlbum): ?>
        <div class="create-playlist" onclick="toggleAddPlayList(true)">
            <div class="wrapper-icom">
                <i class="fa-regular fa-square-plus"></i>
            </div>
            <p>tạo playlist mới</p>
        </div>
        <?php endif; ?>
        <?php $__currentLoopData = $listAlbum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        
        <div class="items-content">
            <div class="wrapper-items-album">
                <div class="items-album-img">
                    <img src="<?php echo e($album->avatar ? $album->avatar : 'anh.jp'); ?>" alt="" onerror="replaceEmptyImage(this)">
                </div>
                <?php if($check): ?>
                    <button class="item-actions" 
                        <?php if(auth()->guard('user')->check()): ?> 
                            onclick="likePlayList(this,'<?php echo e($album->id); ?>','<?php echo e($album->title); ?>')"  
                        <?php else: ?> 
                            onclick="showAlerLogin()" 
                        <?php endif; ?>
                    >
                    <?php if(auth()->guard('user')->check()): ?>
                        <?php if(Auth::guard('user')->user()->checkLikePlaylists($album->id)): ?>
                            <i class="fa-solid fa-heart"></i>
                        <?php else: ?>
                            <i class="fa-regular fa-heart"></i>

                        <?php endif; ?>
                        
                    <?php else: ?>
                    
                        <i class="fa-regular fa-heart"></i>
                    <?php endif; ?>
                    </button>
                <?php else: ?>
                    <button class="item-actions" data-id-playlist="<?php echo e($album->id); ?>" data-id-user=" <?php echo e(Auth::guard('user')->user()->id); ?> " onclick="showConfirmDeletePlayList(this,true)">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                <?php endif; ?>
                
                <button class="item-actions play" 
                <?php if($album->songs->count() > 0): ?>
                    onclick="playAlbum('<?php echo e($album->id); ?>')"
                <?php else: ?>
                    onclick="addNotification('notification','Danh sách phát này chưa có bài hát',3000)"
                <?php endif; ?>
                >
                    <i class="fa-regular fa-circle-play"></i>
                </button>
                <?php if($check): ?>
                <button class="item-actions">
                    <i class="fa-solid fa-ellipsis"></i>
                </button>
                <?php else: ?>
                <!-- Edit -->
                    <a href="<?php echo e(route('site.mymusic.playlist.edit',['slugPlaylist'=>$album->slug])); ?>" class="item-actions">
                        <i class="fa-solid fa-pencil"></i>
                    </a>
                <!-- end edit -->
                <?php endif; ?>
            </div>
            <div class="name-user-album">
                <a href="<?php echo e(route('site.song.album',['albumSlug'=>$album->slug])); ?>" class="name"><?php echo e($album->title); ?></a>
                <br>
                <span ><?php echo e($album->user->name); ?></span>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
</div>
<?php if(!$check): ?>
<script>
    const reloadPagePlaylist = true
</script>
<?php endif; ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/components/list-album.blade.php ENDPATH**/ ?>