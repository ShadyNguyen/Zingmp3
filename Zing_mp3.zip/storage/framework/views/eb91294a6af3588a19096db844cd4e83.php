
<?php $__env->startSection('title', 'Chỉnh sửa'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listAlbum.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/site/css/components/listArtist.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/partials/paginateCustom.css')); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="search-content">

    <div class="search-header">
        <div class="search-header-content">
            <div class="header-content-title">
                <h3>Playlist</h3>
            </div>
            <div class="border-height" style="height: 4rem;">
                <div></div>
            </div>

            <a href="#" class="header-content-item active">
                <span>
                    <?php echo e($playlist->title); ?>

                </span>
            </a>

        </div>
    </div>
    <div class="search-content">
        <div class="search-content-items search-content-header">
            <div class="items-content edit">
                <div class="wrapper-items-album">
                    <div class="items-album-img">
                        <img src="<?php echo e($playlist->avatar ? $playlist->avatar : 'anh.jp'); ?>" alt="" onerror="replaceEmptyImage(this)">
                    </div>
                    <button class="item-actions play" <?php if($playlist->songs->count() > 0): ?>
                        onclick="playAlbum('<?php echo e($playlist->id); ?>')"
                        <?php else: ?>
                        onclick="addNotification('notification','Danh sách phát này chưa có bài hát',3000)"
                        <?php endif; ?>
                        >
                        <i class="fa-regular fa-circle-play"></i>
                    </button>

                </div>
                <div class="name-user-album">
                    <div class="action">
                        <a href="#" class="name">
                            <?php echo e($playlist->title); ?>

                            <span>
                                <button class="item-actions" <?php if(auth()->guard('user')->check()): ?> onclick="likePlayList(this,'<?php echo e($playlist->id); ?>','<?php echo e($playlist->title); ?>')" <?php else: ?> onclick="showAlerLogin()" <?php endif; ?>>
                                    <?php if(auth()->guard('user')->check()): ?>
                                    <?php if(Auth::guard('user')->user()->checkLikePlaylists($playlist->id)): ?>
                                    <i class="fa-solid fa-heart"></i>
                                    <?php else: ?>
                                    <i class="fa-regular fa-heart"></i>

                                    <?php endif; ?>

                                    <?php else: ?>

                                    <i class="fa-regular fa-heart"></i>
                                    <?php endif; ?>
                                </button>
                            </span>
                        </a>

                    </div>

                    <span>Tạo bởi <strong><?php echo e($playlist->user->name); ?></strong> </span>
                    <span> <?php echo e($playlist->status? "Công khai": "Riêng tư"); ?> </span>

                </div>
            </div>
            <div style="width: 100%;">
                <div class="edit-wrapper">
                    <div class="search-content-item-title">
                        <p>Bài hát</p>
                    </div>
                    <?php $__currentLoopData = $playlist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="search-content-item-song">
                        <?php if (isset($component)) { $__componentOriginal40d7a89479f4bcd0af537566bf834f7f = $component; } ?>
<?php $component = App\View\Components\Song::resolve(['song' => $song] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('song'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Song::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f)): ?>
<?php $component = $__componentOriginal40d7a89479f4bcd0af537566bf834f7f; ?>
<?php unset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f); ?>
<?php endif; ?>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if($playlist->songs()->count() == 0): ?>
                <div class="search-content-items no-content">
                    <div class="wrapper-icon">
                        <i class="fa-solid fa-compact-disc"></i>
                    </div>
                    <p>Không có bài hát nào</p>
                </div>
                <?php endif; ?>
            </div>


        </div>

    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/album.blade.php ENDPATH**/ ?>