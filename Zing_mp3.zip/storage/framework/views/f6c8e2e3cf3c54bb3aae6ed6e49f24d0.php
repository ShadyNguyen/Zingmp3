<h1>
  <a href="<?php echo e(route('admin.auth.logout')); ?>">adasd</a>
</h1>
<p>Welcome, Admin: <?php echo e(Auth::guard('admin')->user()->name); ?>!</p>

<?php if(auth()->guard('admin')->check()): ?>
    <p>asdasd</p>  
    <!-- Hiển thị nội dung cho quyền admin -->
    <p>asd</p>
    <p>Welcome, Admin: <?php echo e(Auth::guard('admin')->user()->name); ?>!</p>
<?php endif; ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>