
<?php $__env->startSection('title', 'Tìm kiếm'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/pages/search/main.css')); ?>">

<link rel="stylesheet" href="<?php echo e(url('public/partials/paginateCustom.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="search-content">
        <div class="search-header">
            <div class="search-header-content">
                <div class="header-content-title">
                    <h3>Kết quả tìm kiếm</h3>
                </div>
                <div class="border-height" style="height: 4rem;">
                    <div></div>
                </div>
                <a href="<?php echo e(route('site.search.all',['q'=>$lastQ])); ?>" class="header-content-item">
                    <span>
                        Tất cả
                    </span>
                </a>
                <a href="<?php echo e(route('site.search.song',['q'=>$lastQ])); ?>" class="header-content-item active">
                    <span>
                        Bài hát
                    </span>
                </a>
                <a href="<?php echo e(route('site.search.playlist',['q'=>$lastQ])); ?>" class="header-content-item">
                    <span>
                        Playlist
                    </span>
                </a>
                <a href="<?php echo e(route('site.search.artist',['q'=>$lastQ])); ?>" class="header-content-item">
                    <span>
                        Nghệ sĩ
                    </span>
                </a>
            </div>
        </div>
        <div class="search-content">
            <div class="search-content-items">
                <?php if($listRsSong->count() > 0): ?>
                <div class="search-content-item-title">
                    <p>Bài hát</p>
                    
                    <div>
                    <?php echo e($listRsSong->withQueryString()->links('partials.paginateCustom')); ?>


                    </div>
                </div>
                <div class="search-list-song">
                    <?php $__currentLoopData = $listRsSong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-content-item-song">
                                <?php if (isset($component)) { $__componentOriginal40d7a89479f4bcd0af537566bf834f7f = $component; } ?>
<?php $component = App\View\Components\Song::resolve(['song' => $song] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('song'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Song::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f)): ?>
<?php $component = $__componentOriginal40d7a89479f4bcd0af537566bf834f7f; ?>
<?php unset($__componentOriginal40d7a89479f4bcd0af537566bf834f7f); ?>
<?php endif; ?>
                            </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>

            
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/pages/site/search/song.blade.php ENDPATH**/ ?>