<!-- item -->
<div class="wrapper-items-song dropdown" <?php if($isDelete): ?> data-song-id="<?php echo e($song->id); ?>" <?php endif; ?>>
    <button class="item-actions none">
        <i class="fa-regular fa-square-check"></i>
    </button>
    <!-- song -->
    <div class="item-song">
        <div class="item-song-wrapper">
            <div class="item-song-content">
                <div class="song-thumb">
                    <img src="<?php echo e($song->thumbnail); ?>" alt="">
                    <button class="song-thumb-action" onclick="addSongToListBtn('<?php echo e($song->id); ?>')">
                        <i class="fa-solid fa-play "></i>
                        <i class="fa-regular fa-circle-pause fa-spin hidden"></i>
                    </button>
                </div>
                <div class="song-info">
                    <a href="<?php echo e(route('site.song.home',['songSlug'=>$song->slug])); ?>" class="song-info-name"><span><?php echo e($song->name); ?></span></a>
                    <a href="<?php echo e(route('site.artist.home',['aritistSlug' => $song->user->slug])); ?>" class="song-info-astist">
                        <span><?php echo e($song->user->name); ?>

                            <?php if($song->user->is_celeb): ?>
                            <i class="fa-solid fa-star"></i>
                            <?php endif; ?>
                        </span>
                    </a>
                </div>

            </div>
        </div>
    </div>

    <!-- like btn -->
    <?php if(auth()->guard('user')->check()): ?>
        <?php if($isLike): ?>
            <button class="item-actions" data-name-song="<?php echo e($song->name); ?>" onclick="likeSong(this,'<?php echo e($song->id); ?>')">
                <i class="fa-solid fa-heart active"></i>
            </button>

        <?php else: ?>
            <button class="item-actions" data-name-song="<?php echo e($song->name); ?>" onclick="likeSong(this,'<?php echo e($song->id); ?>')">
                <i class="fa-regular fa-heart"></i>
            </button>
        <?php endif; ?>
    <?php else: ?>
            <button class="item-actions" onclick="showAlerLogin()">
                <i class="fa-regular fa-heart"></i>
            </button>
    <?php endif; ?>
    <!-- end like btn -->



    <button class="item-actions" id="id-more-song-<?php echo e($song->id); ?>" data-bs-auto-close="outside" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="fa-solid fa-ellipsis"></i>
    </button>
    <!-- more song -->
    <div class="dropdown-menu song-menu" aria-labelledby="id-more-song-<?php echo e($song->id); ?>">
        <div class="menu-list song-info-menu">
            <div class="thumb-song">
                <img src="<?php echo e($song->thumbnail); ?>" alt="">
            </div>
            <div class="content-song">
                <p class="content-song-title"><?php echo e($song->name); ?></p>
                <div class="content-song-stats">
                    <div class="stat-item">
                        <i class="fa-regular fa-heart"></i>
                        <span><?php echo e($song->user->name); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="menu-list group-button-menu">
            <div class="button-menu-item">
                <i class="fa-solid fa-download"></i>
                <span>
                    Tải xuống
                </span>
            </div>
            <div class="button-menu-item">
                <i class="fa-solid fa-download"></i>
                <span>
                    Tải xuống
                </span>
            </div>
            <div class="button-menu-item">
                <i class="fa-solid fa-download"></i>
                <span>
                    Tải xuống
                </span>
            </div>
        </div>

        <div class="menu-list-action-item">
            <div class="action-item-content" onclick="setSongBtn('<?php echo e($song->id); ?>')">
                <div><i class="fa-brands fa-google-play"></i></div>
                <span>Thêm vào danh sách phát</span>
            </div>
        </div>

        <div class="menu-list-action-item">
            <div class="action-item-content" onclick="setNextSongBtn('<?php echo e($song->id); ?>')">
                <div><i class="fa-solid fa-forward"></i></div>
                <span>Phát tiếp theo</span>
            </div>
        </div>

        


        <div class="menu-list action ">
            <div class="menu-list-action-item dropstart">
                <div class="action-item-content" id="id-more-song-add-play-list-<?php echo e($song->id); ?>"  data-bs-toggle="dropdown" aria-expanded="false">
                    <div><i class="fa-solid fa-circle-plus"></i></div>
                    <span>Thêm vào playlist</span>
                    <div class="icon-sub">
                        <i class="fa-solid fa-chevron-right"></i>
                    </div>
                </div>
                <ul class="dropdown-menu sub-menu-song add-play-list" aria-labelledby="id-more-song-add-play-list-<?php echo e($song->id); ?>">
                    <div class="action-item-content">
                        <input type="text" placeholder="Tìm playlist">
                    </div>
                    
                    <div class="menu-list-action-item mt-3" <?php if(auth()->guard('user')->check()): ?> onclick="toggleAddPlayList(true)" <?php else: ?> onclick="showAlerLogin()" <?php endif; ?>>
                        <div class="action-item-content">
                            <div class="wrapper-icon add-playlist-i">
                                <i class="fa-solid fa-plus "></i>
                            </div>
                            <span>Tạo playlist mới</span>
                        </div>
                    </div>
                    <?php if(auth()->guard('user')->check()): ?>
                        <?php if(Auth::guard('user')->user()->playLists->count() > 0): ?>
                            <?php $__currentLoopData = Auth::guard('user')->user()->playLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="menu-list-action-item" data-name="<?php echo e($playList->title); ?>" data-add-song-playlist-song="<?php echo e($song->id); ?>" data-add-song-playlist-user="<?php echo e(Auth::guard('user')->user()->id); ?>" data-add-song-playlist-id="<?php echo e($playList->id); ?>">
                                <div class="action-item-content">
                                    <div class="wrapper-icon">
                                        <i class="fa-solid fa-music"></i>
                                    </div>
                                    <span><?php echo e($playList->title); ?></span>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="action-item-content empty-content">
                                <div class="wrapper-icon">
                                    <i class="fa-solid fa-icons"></i>
                                </div>
                                <span>Không có playlist</span>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                    <div class="action-item-content empty-content">
                        <div class="wrapper-icon">
                            <i class="fa-solid fa-icons"></i>
                        </div>
                        <span>Không có playlist</span>
                    </div>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div class="menu-list-action-item dropstart" onclick="copyLinkToClipboard(this,'<?php echo e($song->id); ?>')" data-link-copy="<?php echo e(route('site.song.home',['songSlug'=>$song->slug])); ?>">
            <div class="action-item-content">
                <div><i class="fa-regular fa-copy"></i></div>
                <span>Sao chép link</span>
            </div>
        </div>
        <?php if($isDelete): ?>
        
        <div class="menu-list-action-item dropstart" onclick="removeSongFromPlaylist('<?php echo e($song->id); ?>','<?php echo e($song->name); ?>')">
            <div class="action-item-content">
                <div><i class="fa-regular fa-trash-can"></i></div>
                <span>Xóa ra khỏi play list này</span>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
    <!-- end more song -->




</div>
<!-- End item --><?php /**PATH D:\Hoc\Xampp\htdocs\Zing_mp3\resources\views/components/song.blade.php ENDPATH**/ ?>