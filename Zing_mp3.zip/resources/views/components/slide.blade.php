<div class="slide-page">
    <div class="slide-wrapper">
        <div class="carousel slide slide-wrapper-content" data-bs-ride="carousel" id="slide-page">
            <div class="slide-items carousel-item active">
                <div class="slide-item-list-album">
                    <div class="slide-item-album">
                        <a href=""><img src="https://photo-zmp3.zmdcdn.me/banner/1/4/a/6/14a6bc4408e442dc2a892e1d4a189887.jpg" alt=""></a>
                    </div>
                    <div class="slide-item-album">
                        <a href=""><img src="https://photo-zmp3.zmdcdn.me/banner/e/2/9/1/e2917910851c112d22209b2aa8d6e9a9.jpg" alt=""></a>
                    </div>
                    <div class="slide-item-album">
                        <a href=""><img src="https://photo-zmp3.zmdcdn.me/banner/0/a/4/1/0a417c2e9a463131c8d70465e357770b.jpg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="slide-items carousel-item">
                <div class="slide-item-list-album">
                    <div class="slide-item-album">
                        <a href=""><img src="https://photo-zmp3.zmdcdn.me/banner/1/4/a/6/14a6bc4408e442dc2a892e1d4a189887.jpg" alt=""></a>
                    </div>
                    <div class="slide-item-album">
                        <a href=""><img src="https://photo-zmp3.zmdcdn.me/banner/e/2/9/1/e2917910851c112d22209b2aa8d6e9a9.jpg" alt=""></a>
                    </div>
                    <div class="slide-item-album">
                        <a href=""><img src="https://photo-zmp3.zmdcdn.me/banner/0/a/4/1/0a417c2e9a463131c8d70465e357770b.jpg" alt=""></a>
                    </div>
                </div>
            </div>

        </div>


        <!-- action -->
        <button class="carousel-control-prev slide-action prev" type="button" data-bs-target="#slide-page" data-bs-slide="prev">
            <div class="wrapper-icon">

                <i class="fa-solid fa-angle-left"></i>
            </div>
        </button>
        <button class="carousel-control-next slide-action next" type="button" data-bs-target="#slide-page" data-bs-slide="next">
            <div class="wrapper-icon">

                <i class="fa-solid fa-angle-left fa-rotate-180"></i>
            </div>
        </button>
        <!-- end action -->

    </div>
</div>