<div class="list-album-wrapper">
    @if(!empty($title))
    <div class="main-items-header">
        <div class="items-header-title">
            {{ $title }}
        </div>
    </div>
    @endif
    <div class="main-items-content album">
        <div class="items-content">
            <div class="wrapper-items-album">
                <div class="items-album-img">
                    <img src="https://photo-resize-zmp3.zmdcdn.me/w320_r1x1_webp/cover/a/b/7/a/ab7aec69a53caaa0225097e2a4495dcb.jpg" alt="">
                </div>
                <button class="item-actions">
                    <i class="fa-regular fa-heart"></i>
                </button>
                <button class="item-actions play">
                    <i class="fa-regular fa-circle-play"></i>
                </button>
                <button class="item-actions">
                    <i class="fa-solid fa-ellipsis"></i>
                </button>
            </div>
            <div class="name-user-album">
                <a>Tên tao</a>
            </div>
        </div>
        <div class="items-content">
            <div class="wrapper-items-album">
                <div class="items-album-img">
                    <img src="https://photo-resize-zmp3.zmdcdn.me/w320_r1x1_webp/cover/a/b/7/a/ab7aec69a53caaa0225097e2a4495dcb.jpg" alt="">
                </div>
                <button class="item-actions">
                    <i class="fa-regular fa-heart"></i>
                </button>
                <button class="item-actions play">
                    <i class="fa-regular fa-circle-play"></i>
                </button>
                <button class="item-actions">
                    <i class="fa-solid fa-ellipsis"></i>
                </button>
            </div>
            <div class="name-user-album">
                <a>Tên tao</a>
            </div>
        </div>
        <div class="items-content">
            <div class="wrapper-items-album">
                <div class="items-album-img">
                    <img src="https://photo-resize-zmp3.zmdcdn.me/w320_r1x1_webp/cover/a/b/7/a/ab7aec69a53caaa0225097e2a4495dcb.jpg" alt="">
                </div>
                <button class="item-actions">
                    <i class="fa-regular fa-heart"></i>
                </button>
                <button class="item-actions play">
                    <i class="fa-regular fa-circle-play"></i>
                </button>
                <button class="item-actions">
                    <i class="fa-solid fa-ellipsis"></i>
                </button>
            </div>
            <div class="name-user-album">
                <a>Tên tao</a>
            </div>
        </div>
        <div class="items-content">
            <div class="wrapper-items-album">
                <div class="items-album-img">
                    <img src="https://photo-resize-zmp3.zmdcdn.me/w320_r1x1_webp/cover/a/b/7/a/ab7aec69a53caaa0225097e2a4495dcb.jpg" alt="">
                </div>
                <button class="item-actions">
                    <i class="fa-regular fa-heart"></i>
                </button>
                <button class="item-actions play">
                    <i class="fa-regular fa-circle-play"></i>
                </button>
                <button class="item-actions">
                    <i class="fa-solid fa-ellipsis"></i>
                </button>
            </div>
            
            <div class="name-user-album">
                <a>Album1</a>
               
            </div>
        </div>
        
    </div>
</div>